About:

  This is NotifySystem6, a nostalgic display style for Growl Notifications.

Info:

  If you wish to turn off anti-aliasing for that really old-school look, you
  may do so by opening a terminal and issuing the command:
  
  defaults write com.Growl.GrowlHelperApp AppleAntiAliasingThreshold 128
  
  Then, restart Growl in the preference pane.
  
  If you later decide that you want your antialiasing back, go to 
  Library/Preferences in your home directory, and open the file
  com.Growl.GrowlHelperApp.plist with the Property List Editor, and delete
  the AppleAntiAliasingThreshold property.

Licensing:

  This style is in the public domain - you may modify, copy and distribute
  it as you wish. However, I would appreciate an email to adrian@rollett.org
  if you improve it, and attribution in any re-distribution.
